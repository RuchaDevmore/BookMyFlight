package com.bookmyflight;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookMyFlightApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookMyFlightApplication.class, args);
	}

}
