package com.bookmyflight;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookMyFlightApplicationTests {

	@Test
	void contextLoads() {
	}

}
