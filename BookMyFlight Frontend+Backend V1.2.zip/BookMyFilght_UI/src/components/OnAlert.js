function OnAlert(){
    return(
    alert("Hooray! Thank you for booking")
    )
}

export default OnAlert;